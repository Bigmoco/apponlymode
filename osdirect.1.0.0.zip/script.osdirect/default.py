import xbmc

xbmc.executebuiltin("ActivateWindow(videoosd)")