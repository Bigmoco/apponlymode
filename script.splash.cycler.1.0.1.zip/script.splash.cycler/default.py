import xbmc
import xbmcvfs
import os
import random
import shutil

SPLASH_FOLDER = xbmcvfs.translatePath("special://home/media/splashes/")
TARGET_SPLASH = xbmcvfs.translatePath("special://home/media/splash.png")


def paths_are_same(src, dst):
    """
    Xbox (UWP) normalizes many virtual paths to the same actual location.
    To avoid SameFileError, we compare normalized absolute paths.
    """
    src_norm = os.path.normcase(os.path.abspath(src))
    dst_norm = os.path.normcase(os.path.abspath(dst))
    return src_norm == dst_norm


def safe_copy(src, dst):
    """
    Performs a file copy only if the resolved paths are different.
    Prevents shutil.SameFileError on Xbox and other platforms.
    """
    try:
        if paths_are_same(src, dst):
            xbmc.log(f"[Bigmoco Splash] Skipping copy — '{src}' and '{dst}' resolve to same file.", xbmc.LOGINFO)
            return

        # Ensure directory exists
        dst_dir = os.path.dirname(dst)
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)

        shutil.copy(src, dst)
        xbmc.log(f"[Bigmoco Splash] Copied splash: {src} → {dst}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Bigmoco Splash] ERROR copying splash: {e}", xbmc.LOGERROR)


def choose_random_splash():
    if not os.path.exists(SPLASH_FOLDER):
        xbmc.log("[Bigmoco Splash] Splash folder does not exist.", xbmc.LOGWARNING)
        return

    images = [f for f in os.listdir(SPLASH_FOLDER)
              if f.lower().endswith(".png")]

    if not images:
        xbmc.log("[Bigmoco Splash] No PNG images found in splash folder.", xbmc.LOGWARNING)
        return

    selected = random.choice(images)
    src = os.path.join(SPLASH_FOLDER, selected)

    xbmc.log(f"[Bigmoco Splash] Selected random splash: {selected}", xbmc.LOGINFO)
    safe_copy(src, TARGET_SPLASH)


if __name__ == "__main__":
    choose_random_splash()