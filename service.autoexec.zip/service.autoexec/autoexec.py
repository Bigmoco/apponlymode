import xbmc
import time

time.sleep(5)  # Wait for 5 seconds before executing the command
xbmc.executebuiltin('ReloadSkin()')  # Reload the skin

