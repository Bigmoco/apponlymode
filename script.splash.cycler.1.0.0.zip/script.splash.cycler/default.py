import xbmc
import xbmcvfs
import os
import random
import shutil

SPLASH_FOLDER = xbmcvfs.translatePath("special://home/media/splashes/")
TARGET_SPLASH = xbmcvfs.translatePath("special://home/media/splash.png")

def choose_random_splash():
    if not os.path.exists(SPLASH_FOLDER):
        return
    images = [f for f in os.listdir(SPLASH_FOLDER)
              if f.lower().endswith(".png")]
    if not images:
        return

    selected = random.choice(images)
    src = os.path.join(SPLASH_FOLDER, selected)
    shutil.copy(src, TARGET_SPLASH)

if __name__ == "__main__":
    choose_random_splash()
